﻿using ProtocolLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProtocolManagerForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            RegisterMachins();
            ReadPosition();
        }

        private void RegisterMachins() { 
            ProtocolLib.Protocol modbus = new ProtocolLib.Protocol(); //初始化管理器
            //modbus.CustomName = "Modbus1";
            modbus.IP = "127.0.0.1";
            modbus.Port = 503;
            modbus.ReceiveTimeOut = 300;
            modbus.ConnectTimeOut = 1000;
            modbus.SleepTime = 1;
            modbus.ScanTime = 100;
            modbus.Type = ProtocolLib.ProtocolType.Modbus;

            modbus.RegisterReadTag("狀態群組", "0", 3, new List<string>() { "機械X", "機械Y", "機械Z", }, ProtocolLib.Type.ProtocolType.ProtocolTypeList.Int32);
            modbus.RegisterWriteTag("停止按鈕" , "10" , ProtocolLib.Type.ProtocolType.ProtocolTypeList.Bool , false);
            modbus.RegisterWriteTag("座標陣列", "0", ProtocolLib.Type.ProtocolType.ProtocolTypeList.Int32, true);

            ProtocolLib.ProtocolManager.Instance.RegisterMachin("Modbus", modbus);
            ProtocolLib.ProtocolManager.Instance.Start();
        }

        /// <summary>
        /// 讀取按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (ProtocolLib.ProtocolManager.Instance.GetMachin("Modbus" , out Protocol modbus))
            {
                var posX = modbus.GetValue<int>("狀態群組", "機械X");
                Console.WriteLine(String.Format("機械X:{0} , 狀態: {1}" , posX.Value , posX.IsSuccess));
            }
            else
            {
                MessageBox.Show("找不到機台");
            }
        }
        /// <summary>
        /// 寫入按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private bool flag = false;
        private void button2_Click(object sender, EventArgs e)
        {

            if (ProtocolLib.ProtocolManager.Instance.GetMachin("Modbus", out Protocol modbus)) {
                modbus.WriteTagValue("停止按鈕" , flag);

                if (flag == true)
                {
                    flag = false;
                }
                else
                {
                    flag = true;
                }
            }
            else
            {
                MessageBox.Show("找不到機台");
            }
        }
        /// <summary>
        /// 寫入陣列數據
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            List<int> posList = new List<int>();

            posList.Add(5000); //pos1 X
            posList.Add(5000); //pos1 Y
            posList.Add(5000); //pos1 Z

            posList.Add(7000); //pos2 X
            posList.Add(7000); //pos2 Y
            posList.Add(7000); //pos2 Z

            posList.Add(9000); //pos3 X
            posList.Add(9000); //pos3 Y
            posList.Add(9000); //pos3 Z

            if (ProtocolLib.ProtocolManager.Instance.GetMachin("Modbus", out Protocol modbus))
            {
                modbus.WriteTagValue("座標陣列", posList.ToArray());
            }
            else
            {
                MessageBox.Show("找不到機台");
            }
        }
        /// <summary>
        /// 循環讀取座標
        /// </summary>
        private void ReadPosition() {
            Task.Run(async () => {
                while (true) {
                    if (ProtocolLib.ProtocolManager.Instance.GetMachin("Modbus", out Protocol modbus))
                    {
                        var posX = modbus.GetValue<int>("狀態群組", "機械X");
                        var posY = modbus.GetValue<int>("狀態群組", "機械Y");
                        var posZ = modbus.GetValue<int>("狀態群組", "機械Z");
                        //Console.WriteLine(String.Format("機械X:{0} , 狀態: {1}", posX.Value, posX.IsSuccess));
                        if (IsHandleCreated)
                        {
                            this.BeginInvoke(new EventHandler(delegate {
                                posXlab.Text = (posX.Value / 1000.0).ToString("f3");
                                posYlab.Text = (posY.Value / 1000.0).ToString("f3");
                                posZlab.Text = (posZ.Value / 1000.0).ToString("f3");
                            }));                            
                        }
                    }
                    else
                    {
                        MessageBox.Show("找不到機台");
                    }
                    
                    await Task.Delay(100);
                }                
            });
        }
    }
}
